ComputeEnvConcentrationsCPP = function(basin_data,chem,cons,cores=4){

  # for debugging
  if(FALSE){
    basin_data = basins_avg
    cores = 4
    cons = cons3
    chem = chem3
  }

  # extract river points and lakes
  pts = basin_data$pts
  hl = basin_data$hl

  # prepare data per chemical
  pts_hl = list(pts=data.frame(),hl=data.frame())
  for(chem_ii in 1:nrow(chem)) {

    # copy pts and hl data
    pts_cp = pts
    hl_cp = hl

    # set custom basin id to process chems individually in c++ code
    pts_cp$basin_id = paste0(pts_cp$basin_id,"__",chem$API[chem_ii])
    hl_cp$basin_id = paste0(hl_cp$basin_id,"__",chem$API[chem_ii])

    # set local (spatial-specific) parameters for pts and hl
    pts_hl_params = Set_local_parameters_custom_removal_fast2(pts_cp,hl_cp,cons,chem,chem_ii=chem_ii,UseCpp=FALSE)

    # insert data into global list
    pts_hl$pts = rbind(pts_hl$pts,pts_hl_params$pts)
    pts_hl$hl = rbind(pts_hl$hl,pts_hl_params$hl)

  }

  # Compute env concentrations using epie_engine.exe
  results = epie_engine_wrapper(pts=pts_hl$pts,hl=pts_hl$hl,dev=TRUE,cores=cores)

  # return results
  return(list(pts=results$pts,hl=results$hl))
}
