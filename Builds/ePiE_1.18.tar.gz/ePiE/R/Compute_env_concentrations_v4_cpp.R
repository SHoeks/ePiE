#' Compute Environmental Concentrations (C++ version)
#' 
#' A high-performance C++ implementation of the environmental concentration computation
#' algorithm. This function provides the same functionality as Compute_env_concentrations_v4
#' but with significantly improved performance for large datasets.
#' 
#' @param pts A data frame containing point data with required columns:
#'   ID, Pt_type, ID_nxt, basin_id, x, y, Q, E_w, E_up, k_ws, k_sw, H, H_sed, 
#'   poros, rho_sd, k_NXT, dist_nxt, V_NXT, fin, upcount, f_rem_WWTP.
#'   Optional columns: Hylak_id, lake_out
#' @param HL A data frame containing lake data with columns:
#'   Hylak_id, basin_id, E_in, Vol_total, k, k_ws, k_sw, Depth_avg, H_sed, 
#'   poros, rho_sd, fin
#' @param print Logical indicating whether to print progress information
#' 
#' @return A list containing:
#'   \item{pts}{Data frame with computed concentrations (C_w, C_sd) for each point}
#'   \item{HL}{Data frame with computed concentrations for lakes (if HL provided)}
#' 
#' @examples
#' \dontrun{
#' # Assuming you have pts and HL data frames prepared
#' result <- Compute_env_concentrations_v4_cpp(pts, HL, print = TRUE)
#' }
#' 
#' @export
Compute_env_concentrations_v4_cpp <- function(pts, HL, print = TRUE) {
  
  # Input validation
  if (!is.data.frame(pts)) {
    stop("pts must be a data frame")
  }
  
  if (!is.data.frame(HL)) {
    stop("HL must be a data frame")
  }
  
  # Required columns for pts
  required_pts_cols <- c("ID", "Pt_type", "ID_nxt", "basin_id", "x", "y", "Q", 
                        "E_w", "E_up", "k_ws", "k_sw", "H", "H_sed", "poros", 
                        "rho_sd", "k_NXT", "dist_nxt", "V_NXT", "fin", "upcount", 
                        "f_rem_WWTP")
  
  missing_pts_cols <- setdiff(required_pts_cols, names(pts))
  if (length(missing_pts_cols) > 0) {
    stop("Missing required columns in pts: ", paste(missing_pts_cols, collapse = ", "))
  }
  
  # Add optional columns if missing
  if (!"Hylak_id" %in% names(pts)) {
    pts$Hylak_id <- rep(1L, nrow(pts))
  }
  if (!"lake_out" %in% names(pts)) {
    pts$lake_out <- rep(0L, nrow(pts))
  }
  
  # Required columns for HL (if it has rows)
  if (nrow(HL) > 0) {
    required_HL_cols <- c("Hylak_id", "basin_id", "E_in", "Vol_total", "k", 
                         "k_ws", "k_sw", "Depth_avg", "H_sed", "poros", 
                         "rho_sd", "fin")
    
    missing_HL_cols <- setdiff(required_HL_cols, names(HL))
    if (length(missing_HL_cols) > 0) {
      stop("Missing required columns in HL: ", paste(missing_HL_cols, collapse = ", "))
    }
  }
  
  # Call the C++ function
  result <- compute_env_concentrations_cpp(pts, HL, print)
  
  return(result)
}

#' Compute Environmental Concentrations (Hybrid version)
#' 
#' A wrapper function that automatically chooses between R and C++ implementation
#' based on data size for optimal performance.
#' 
#' @param pts A data frame containing point data
#' @param HL A data frame containing lake data  
#' @param print Logical indicating whether to print progress information
#' @param force_cpp Logical to force C++ implementation regardless of size
#' @param size_threshold Number of points above which to use C++ (default: 1000)
#' 
#' @return A list containing computed concentrations
#' 
#' @export
Compute_env_concentrations_v4_auto <- function(pts, HL, print = TRUE, 
                                              force_cpp = FALSE, 
                                              size_threshold = 1000) {
  
  if (force_cpp || nrow(pts) > size_threshold) {
    if (print) {
      message("Using C++ implementation for improved performance")
    }
    return(Compute_env_concentrations_v4_cpp(pts, HL, print))
  } else {
    if (print) {
      message("Using R implementation for small dataset")
    }
    return(Compute_env_concentrations_v4(pts, HL, print))
  }
}
