CheckConsumptionData = function(pts,chem,cons,fill_gaps = FALSE){

  # fill gaps
  if(fill_gaps){
    # ...
  }

  # run check
  cons = Check_cons_v2(pts,chem,cons)

}
