epie_engine_wrapper = function(exec_path="",pts,hl,dev=TRUE,cores=4) {

  # get executable path
  lib_name = 'ePiE'
  lib_paths = .libPaths()
  libPath = paste0(lib_paths[grep(lib_name,lapply(lib_paths,list.files))][1],'/',lib_name)
  if(!file.exists(exec_path)){
    switch(Sys.info()[['sysname']],
           Windows = {exec_path = paste0(libPath,'/win_exec/epie_engine.exe')},
           Darwin = {exec_path = paste0(libPath,'/mac_exec/epie_engine.exe')},
           Linux = {exec_path = paste0(libPath,'/linux_exec/epie_engine.exe')})
  }

  # split executable name and path
  exec_path = strsplit(exec_path,"/")[[1]]
  exec_name = exec_path[length(exec_path)]
  exec_path = exec_path[1:(length(exec_path)-1)]
  exec_path = paste0(exec_path,collapse="/")
  if(dev) print(exec_path)
  if(dev) print(exec_name)

  # print in dev mode
  if(dev) print(file.info(file.path(exec_path,exec_name)))

  # create temporary output path
  tmp_out_dir = paste0(tempdir(),"/epie_engine_tmp_",format(Sys.time(), "%d_%m_%y_%H_%M_%S"),"/")

  # remove slashes at end of tmp_out_dir path
  if(substr(tmp_out_dir,(nchar(tmp_out_dir)+1)-1,nchar(tmp_out_dir))=='/')  tmp_out_dir=substr(tmp_out_dir,1,nchar(tmp_out_dir)-1)
  if(substr(tmp_out_dir,(nchar(tmp_out_dir)+1)-1,nchar(tmp_out_dir))=='\\') tmp_out_dir=substr(tmp_out_dir,1,nchar(tmp_out_dir)-1)

  # replace \\ by / windows
  if(Sys.info()[['sysname']]=="Windows") tmp_out_dir = gsub('\\\\', '/', tmp_out_dir)

  # create temp output dir
  if(dev) print(tmp_out_dir)
  dir.create(tmp_out_dir, showWarnings = FALSE, recursive = TRUE)

  # write c++ csv input files
  pts_in_path = paste0(tmp_out_dir,"/pts.csv")
  pts = pts[,c("ID","ID_nxt","basin_id","fin","upcount","lake_out","Hylak_id","E_w","E_up","C_w","C_sd","Q","E_w_NXT","k_NXT","k_ws","k_sw","H_sed","H","poros","rho_sd","dist_nxt","V_NXT","f_rem_WWTP")]
  write.csv(pts,pts_in_path,row.names=FALSE)
  hl_in_path = paste0(tmp_out_dir,"/hl.csv")
  hl = hl[,c("fin","Vol_total","k","k_ws","Depth_avg","H_sed","poros","rho_sd","C_w","C_sd","Hylak_id","E_in","k_sw","basin_id")]
  write.csv(hl,hl_in_path,row.names=FALSE)
  if(dev) print(list.files(tmp_out_dir))

  # create output csv file paths
  pts_out_path = paste0(tmp_out_dir,"/pts_out.csv")
  hl_out_path = paste0(tmp_out_dir,"/hl_out.csv")

  # Run the C++ code (run)
  switch(Sys.info()[['sysname']],

    # run on windows
    Windows = {

      # setup C++ input arguments
      exec_args = paste('"%PATH1%"','"%PATH2%"','"%PATH3%"','"%PATH4%"',cores)

      # setup windows executable path
      epie_exec = paste0('"',exec_path,"/",exec_name,'" ')

      # create epie_engine.bat file for running the C++ code
      bat_l1 = "ECHO off"
      bat_l2 = paste0("set PATH1=",paste0(gsub("/", "\\\\", pts_in_path)))
      bat_l3 = paste0("set PATH2=",paste0(gsub("/", "\\\\", hl_in_path)))
      bat_l4 = paste0("set PATH3=",paste0(gsub("/", "\\\\", pts_out_path)))
      bat_l5 = paste0("set PATH4=",paste0(gsub("/", "\\\\", hl_out_path)))
      bat_l6 =  paste(epie_exec,exec_args)
      bat_l6 = gsub("/", "\\\\", bat_l6)
      run_exec = paste0(exec_path,'/epie_engine.bat')
      writeLines(c(bat_l1,bat_l2,bat_l3,bat_l4,bat_l5,bat_l6), run_exec)
      if(dev) print(readLines(run_exec))
      run_exec = paste0('"',run_exec,'"')
      if(dev)print(run_exec)

      # call bat file (run c++ executable)
      system(run_exec)

      # load results and return data
      if(file.exists(pts_out_path) & file.exists(hl_out_path)){
        pts_out = read.csv(pts_out_path)
        hl_out = read.csv(hl_out_path)
        return(list(pts=pts_out,hl=hl_out))
      }else{
        stop("no outputs available from epie run")
      }
    },

    # run on linux
    Linux = {

      print("binary not avialable... coming soon!")
      # # setup C++ input arguments
      # sp_dir = paste0(out_dir,"/spatial_inputs/1deg/")
      # exec_args = paste(spatial_window,
      #                   paste0('\"',gsub("\\\\", "/", out_dir),'\"'),
      #                   output_ts_months,
      #                   gridout_bool,
      #                   paste0('\"',gsub("\\\\", "/", input_dir),'\"'),
      #                   max_cohort,
      #                   paste0('\"',gsub("\\\\", "/", paste0(input_dir,"C.csv")),'\"'),
      #                   paste0('\"',gsub("\\\\", "/", paste0(input_dir,"S.csv")),'\"'),
      #                   start_t,
      #                   paste0('\"',gsub("\\\\", "/", sp_dir),'\"'),
      #                   grid_size,
      #                   hanpp,
      #                   NoDispersal,
      #                   int_RunInParallel,
      #                   model_params)
      #
      # # setup linux executable path
      # lin_dist_dir = paste0('"',get_lib_path(),'/lin_exec/','"')
      # system(paste('cd',lin_dist_dir,'&&','chmod u+x madingley'))
      # madingley_exec = paste('cd',lin_dist_dir,'&&','./madingley run',years,exec_args)
      #
      #
      # # init model
      # #cat(madingley_exec)
      # if(silenced){
      #   print_out = system(madingley_exec,intern=T)
      # }else{
      #   system(madingley_exec)
      # }
      #
      # # return data
      # out = return_output_list_run(cohort_def,stock_def,out_dir,out_dir_name)
      # out$spatial_window = madingley_data$spatial_window
      # if(!out_dir_save==tempdir()){
      #   out$out_path = out_dir_save
      # }
      # out$grid_size = grid_size
      # return(out)


    },

    # run on mac
    Darwin = {

      print("binary not avialable... coming soon!")
      # # setup C++ input arguments
      # sp_dir = paste0(out_dir,"/spatial_inputs/1deg/")
      # exec_args = paste(spatial_window,
      #                   paste0('\"',gsub("\\\\", "/", out_dir),'\"'),
      #                   output_ts_months,
      #                   gridout_bool,
      #                   paste0('\"',gsub("\\\\", "/", input_dir),'\"'),
      #                   max_cohort,
      #                   paste0('\"',gsub("\\\\", "/", paste0(input_dir,"C.csv")),'\"'),
      #                   paste0('\"',gsub("\\\\", "/", paste0(input_dir,"S.csv")),'\"'),
      #                   start_t,
      #                   paste0('\"',gsub("\\\\", "/", sp_dir),'\"'),
      #                   grid_size,
      #                   hanpp,
      #                   NoDispersal,
      #                   int_RunInParallel,
      #                   model_params)
      #
      # # setup linux executable path
      # mac_dist_dir = paste0('"',get_lib_path(),'/mac_exec/','"')
      # system(paste('cd',mac_dist_dir,'&&','chmod u+x madingley'))
      # madingley_exec = paste('cd',mac_dist_dir,'&&','./madingley run',years,exec_args)
      #
      #
      # # init model
      # #cat(madingley_exec)
      # if(silenced){
      #   print_out = system(madingley_exec,intern=T)
      # }else{
      #   system(madingley_exec)
      # }
      #
      # # return data
      # out = return_output_list_run(cohort_def,stock_def,out_dir,out_dir_name)
      # out$spatial_window = madingley_data$spatial_window
      # if(!out_dir_save==tempdir()){
      #   out$out_path = out_dir_save
      # }
      # out$grid_size = grid_size
      # #cat(out$grid_size)
      # return(out)

    }
  )

}
