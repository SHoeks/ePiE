ComputeEnvConcentrations = function(basin_data,chem,cons,print=FALSE){

  # extract river points and lakes
  pts = basin_data$pts
  hl = basin_data$hl

  for (chem_ii in 1:nrow(chem)) {

    pts.backup <- pts
    chem.backup <- chem

    # Set local (spatial-specific) parameters for pts and HL (overwrites current variables; pts and HL)
    pts_hl <- Set_local_parameters_custom_removal_fast3(pts,hl,cons,chem,chem_ii)

    # Fate calculations rivers and lakes
    results <- Compute_env_concentrations_v4(pts_hl[[1]],pts_hl[[2]],print)

    results[[1]]$API <- chem$API[chem_ii]
    if (nrow(hl)!=0) results[[2]]$API <- chem$API[chem_ii]

    # Create output
    if(nrow(hl)!=0) {
      if(chem_ii==1){
        results_com <- results[[1]]
        results_lakes <- results[[2]]
      }else{
        results_com <- rbind(results_com,results[[1]])
        results_lakes <- rbind(results_lakes,results[[2]])
      }
    }else{
      results_lakes <- NULL
      if(chem_ii==1) {
        results_com <- results[[1]]
      }else{
        results_com <- rbind(results_com,results[[1]])
      }
    }

    pts<-pts.backup
    chem<- chem.backup
  }

  return(list(pts=results_com,hl=results_lakes))
}
