# Load package
library(ePiE)
library(terra)
library(tictoc)
library(openxlsx)

# Open API-specific data
chem = LoadExampleChemProperties()

# Complete missing values in chem data
chem = CompleteChemProperties(chem = chem)

# Test SimpleTreat
SimpleTreat4_0(chem_class=chem$class[1],MW=chem$MW[1],Pv=chem$Pv[1],S=chem$S[1],pKa=chem$pKa[1],
               Kp_ps=chem$Kp_ps_n[1],Kp_as=chem$Kp_as_n[1],k_bio_WWTP=chem$k_bio_wwtp_n[1],
               T_air=285,Wind=4,Inh=1000,E_rate=1,PRIM=-1,SEC=-1)

# Load example consumption data
cons = LoadExampleConsumption()
#cons[cons$cnt  == "IT", "Ibuprofen"] = 12

# Load basin data, river nodes and lakes, all European basins are included
basins = LoadEuropeanBasins()

# Select example basins, find a better way to select basins
unique(basins$pts$basin_id)
# https://www.hydrosheds.org/products/hydrobasins
basin_ids = c(124863) # Rhine
basins = SelectBasins(basins_data = basins, basin_ids = basin_ids)

# Check whether consumption data are available for the WWTPs in basins
cons = CheckConsumptionData(basins$pts,chem,cons)

# Load river flow
flow_avg = LoadLongTermFlow("average")

# Attach flow to basin data
basins_avg = AddFlowToBasinData(basin_data = basins, flow_rast = flow_avg)
#hist(log10(basins_avg$pts$Q), main = "log10 Flow distribution", xlab = "log10 Flow (m3/s)")

# Run ePiE for all chems, all basins, 1 flow condition
#tic()
results = ComputeEnvConcentrations(basin_data = basins_avg, chem = chem, cons = cons, print=TRUE)
mean(results$pts$WWTPremoval,na.rm=TRUE)
#toc()
str(results,1)

# Compute_env_concentrations_v2 takes 29.9 sec
# Compute_env_concentrations_v2 takes 35.9 sec
# Compute_env_concentrations_v2 takes 32.9 sec
#--------------------------------------------------
# Compute_env_concentrations_v3 takes 12.1 sec
# Compute_env_concentrations_v3 takes 16.91 sec
# Compute_env_concentrations_v3 takes 14.6 sec
#--------------------------------------------------
# Compute_env_concentrations_v4 takes 4.1 sec
# Compute_env_concentrations_v4 takes 3.5 sec
# Compute_env_concentrations_v4 takes 3.5 sec
prev_result1.0 = readRDS("inst/test_results/results_Compute_env_concentrations_v1.0.rds")
all.equal(prev_result1.0,results)
plot(log10(prev_result1.0$pts$C_w),log10(results$pts$C_w))
abline(0,1)

# Save results
# ePiE::ePiEVersion()
# saveRDS(results,"inst/test_results/results_Compute_env_concentrations_v1.097.rds")

# rm frac
pts = results1$pts
rm_frac = mean(results1$pts$WWTPremoval[which(results1$pts$WWTPremoval>0)])
View(pts)

# Calc WWTP emissions
wwtp = basins$pts[which(basins$pts$Pt_type=="WWTP"),]
idx = match(wwtp$rptMStateK,cons$country)
wwtp$cnt_lvl_cons_kgy = cons$Ibuprofen[idx]
wwtp$wwtp_lvl_cons_kgy = wwtp$cnt_lvl_cons_kgy*wwtp$f_STP
wwtp$wwtp_lvl_ems_kgy = wwtp$wwtp_lvl_cons_kgy*rm_frac
View(wwtp)

