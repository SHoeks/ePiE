#include <Rcpp.h>
#include <cmath>
#include <unordered_map>
#include <unordered_set>
using namespace Rcpp;

// [[Rcpp::plugins("cpp11")]]
// [[Rcpp::export]]
List Compute_env_concentrations_v4_cpp(DataFrame &pts, DataFrame &HL, bool print_progress = true) {
  
  // Extract pts columns
  IntegerVector pts_ID = pts["ID"];
  CharacterVector pts_Pt_type = pts["Pt_type"];
  IntegerVector pts_ID_nxt = pts["ID_nxt"];
  IntegerVector pts_basin_id = pts["basin_id"];
  NumericVector pts_x = pts["x"];
  NumericVector pts_y = pts["y"];
  NumericVector pts_Q = pts["Q"];
  NumericVector pts_E_w = pts["E_w"];
  NumericVector pts_E_up = pts["E_up"];
  NumericVector pts_k_ws = pts["k_ws"];
  NumericVector pts_k_sw = pts["k_sw"];
  NumericVector pts_H = pts["H"];
  NumericVector pts_H_sed = pts["H_sed"];
  NumericVector pts_poros = pts["poros"];
  NumericVector pts_rho_sd = pts["rho_sd"];
  NumericVector pts_k_NXT = pts["k_NXT"];
  NumericVector pts_dist_nxt = pts["dist_nxt"];
  NumericVector pts_V_NXT = pts["V_NXT"];
  IntegerVector pts_fin = pts["fin"];
  IntegerVector pts_upcount = pts["upcount"];
  NumericVector pts_f_rem_WWTP = pts["f_rem_WWTP"];
  
  // Handle optional columns
  IntegerVector pts_Hylak_id;
  IntegerVector pts_lake_out;
  
  if (pts.containsElementNamed("Hylak_id")) {
    pts_Hylak_id = pts["Hylak_id"];
  } else {
    pts_Hylak_id = IntegerVector(pts_ID.size(), 1);
  }
  
  if (pts.containsElementNamed("lake_out")) {
    pts_lake_out = pts["lake_out"];
  } else {
    pts_lake_out = IntegerVector(pts_ID.size(), 0);
  }
  
  // Initialize output vectors for pts
  NumericVector pts_C_w(pts_ID.size(), NA_REAL);
  NumericVector pts_C_sd(pts_ID.size(), NA_REAL);
  NumericVector pts_E_w_NXT(pts_ID.size(), 0.0);
  
  // Extract HL columns (if HL has rows)
  IntegerVector HL_Hylak_id;
  IntegerVector HL_basin_id;
  NumericVector HL_E_in;
  NumericVector HL_Vol_total;
  NumericVector HL_k;
  NumericVector HL_k_ws;
  NumericVector HL_k_sw;
  NumericVector HL_Depth_avg;
  NumericVector HL_H_sed;
  NumericVector HL_poros;
  NumericVector HL_rho_sd;
  IntegerVector HL_fin;
  NumericVector HL_C_w;
  NumericVector HL_C_sd;
  
  int HL_size = 0;
  if (HL.nrow() > 0) {
    HL_size = HL.nrow();
    HL_Hylak_id = HL["Hylak_id"];
    HL_basin_id = HL["basin_id"];
    HL_E_in = HL["E_in"];
    HL_Vol_total = HL["Vol_total"];
    HL_k = HL["k"];
    HL_k_ws = HL["k_ws"];
    HL_k_sw = HL["k_sw"];
    HL_Depth_avg = HL["Depth_avg"];
    HL_H_sed = HL["H_sed"];
    HL_poros = HL["poros"];
    HL_rho_sd = HL["rho_sd"];
    HL_fin = HL["fin"];
    HL_C_w = NumericVector(HL_size, NA_REAL);
    HL_C_sd = NumericVector(HL_size, NA_REAL);
  }
  
  // Create index mappings
  std::unordered_map<int, int> HL_map;
  for (int i = 0; i < HL_size; i++) {
    HL_map[HL_Hylak_id[i]] = i;
  }
  
  std::unordered_map<std::string, int> pts_map;
  for (int i = 0; i < pts_ID.size(); i++) {
    std::string key = std::to_string(pts_basin_id[i]) + "_" + std::to_string(pts_ID[i]);
    pts_map[key] = i;
  }
  
  // Create basin_id set for HL for faster lookup
  std::unordered_set<int> HL_basin_set;
  for (int i = 0; i < HL_size; i++) {
    HL_basin_set.insert(HL_basin_id[i]);
  }
  
  // Initialize break detection
  std::vector<int> break_vec;
  
  // Main processing loop
  while (true) {
    // Check if any points remain unfinished
    bool has_unfinished = false;
    int unfinished_count = 0;
    for (int i = 0; i < pts_ID.size(); i++) {
      if (pts_fin[i] == 0) {
        has_unfinished = true;
        unfinished_count++;
      }
    }
    
    if (!has_unfinished) break;
    
    // Print progress
    if (print_progress) {
      int HL_unfinished = 0;
      for (int i = 0; i < HL_size; i++) {
        if (HL_fin[i] == 0) HL_unfinished++;
      }
      Rcout << "# points in pts: " << unfinished_count << std::endl;
      Rcout << "# points in HL: " << HL_unfinished << std::endl;
    }
    
    // Break detection
    break_vec.push_back(unfinished_count);
    if (break_vec.size() > 10) {
      std::unordered_set<int> unique_counts(break_vec.end() - 11, break_vec.end());
      if (break_vec.size() - unique_counts.size() > 10) {
        Rcout << "Breaking due to infinite loop detection" << std::endl;
        break;
      }
    }
    
    // Find points to process
    std::vector<int> pts_to_process;
    for (int i = 0; i < pts_ID.size(); i++) {
      if (pts_fin[i] == 0 && pts_upcount[i] == 0) {
        pts_to_process.push_back(i);
      }
    }
    
    // Process each point
    for (int j : pts_to_process) {
      if (pts_fin[j] != 0) continue;
      
      // Get indices
      int HL_index_match = -1;
      if (HL_map.find(pts_Hylak_id[j]) != HL_map.end()) {
        HL_index_match = HL_map[pts_Hylak_id[j]];
      }
      
      int pts_index_down = -1;
      std::string downstream_key = std::to_string(pts_basin_id[j]) + "_" + std::to_string(pts_ID_nxt[j]);
      if (pts_map.find(downstream_key) != pts_map.end()) {
        pts_index_down = pts_map[downstream_key];
      }
      
      // Process based on point type
      if (HL_basin_set.find(pts_basin_id[j]) != HL_basin_set.end() && pts_lake_out[j] == 1) {
        
        // Lake concentration calculation
        if (HL_index_match >= 0) {
          double E_total = HL_E_in[HL_index_match] + pts_E_w[j] + pts_E_up[j];
          double V = HL_Vol_total[HL_index_match] * 1e6;
          double k = HL_k[HL_index_match];
          pts_C_w[j] = E_total / (pts_Q[j] + k * V) * 1e6 / (365.0 * 24.0 * 3600.0);
          
          double chem_exchange = HL_k_ws[HL_index_match] / HL_k_sw[HL_index_match];
          double H_ratio = HL_Depth_avg[HL_index_match] / HL_H_sed[HL_index_match];
          double dens_transform = HL_poros[HL_index_match] + (1.0 - HL_poros[HL_index_match]) * HL_rho_sd[HL_index_match];
          
          pts_C_sd[j] = pts_C_w[j] * chem_exchange * H_ratio * dens_transform;
          
          // Assign to HL
          HL_C_w[HL_index_match] = pts_C_w[j];
          HL_C_sd[HL_index_match] = pts_C_sd[j];
          HL_fin[HL_index_match] = 1;
          
          // Contribution downstream
          pts_E_w_NXT[j] = pts_C_w[j] * pts_Q[j] * 365.0 * 24.0 * 3600.0 / 1e6 * 
                           exp(-pts_k_NXT[j] * pts_dist_nxt[j] / pts_V_NXT[j]);
          
          if (pts_index_down >= 0) {
            pts_E_up[pts_index_down] += pts_E_w_NXT[j];
            pts_upcount[pts_index_down]--;
          }
        }
        
      } else if (pts_Hylak_id[j] == 0 || pts_lake_out[j] == 1) {
        
        // Node and lake out concentration
        double E_total = pts_E_w[j] + pts_E_up[j];
        pts_C_w[j] = E_total / pts_Q[j] * 1e6 / (365.0 * 24.0 * 3600.0);
        
        double chem_exchange = pts_k_ws[j] / pts_k_sw[j];
        double H_ratio = pts_H[j] / pts_H_sed[j];
        double dens_transform = pts_poros[j] + (1.0 - pts_poros[j]) * pts_rho_sd[j];
        
        pts_C_sd[j] = pts_C_w[j] * chem_exchange * H_ratio * dens_transform;
        
        // Contribution downstream
        pts_E_w_NXT[j] = E_total * exp(-pts_k_NXT[j] * pts_dist_nxt[j] / pts_V_NXT[j]);
        
        if (pts_index_down >= 0) {
          pts_E_up[pts_index_down] += pts_E_w_NXT[j];
          pts_upcount[pts_index_down]--;
        }
        
      } else {
        
        // Lake node concentration
        double E_total = pts_E_w[j] + pts_E_up[j];
        pts_C_w[j] = NA_REAL;
        pts_C_sd[j] = NA_REAL;
        
        // Contribution downstream
        pts_E_w_NXT[j] = E_total;
        
        if (pts_index_down >= 0) {
          pts_E_up[pts_index_down] += pts_E_w_NXT[j];
          pts_upcount[pts_index_down]--;
        }
      }
      
      // Mark as finished
      pts_fin[j] = 1;
    }
  }
  
  // Prepare output
  DataFrame pts_result = DataFrame::create(
    Named("ID") = pts_ID,
    Named("Pt_type") = pts_Pt_type,
    Named("ID_nxt") = pts_ID_nxt,
    Named("basin_ID") = pts_basin_id,
    Named("x") = pts_x,
    Named("y") = pts_y,
    Named("Q") = pts_Q,
    Named("C_w") = pts_C_w,
    Named("C_sd") = pts_C_sd,
    Named("WWTPremoval") = pts_f_rem_WWTP
  );
  
  if (HL_size > 0) {
    DataFrame HL_result = DataFrame::create(
      Named("Hylak_id") = HL_Hylak_id,
      Named("C_w") = HL_C_w,
      Named("C_sd") = HL_C_sd
    );
    
    return List::create(
      Named("pts") = pts_result,
      Named("HL") = HL_result
    );
  } else {
    return List::create(
      Named("pts") = pts_result
    );
  }
}
